const APP_TITLE = 'Hatti Kaapi Staff Attendance';
const DEFAULT_PASSWORD = 'Hatti@123';
const EMPLOYEES = [
  ['2803', 'Ashwath M'],
  ['2878', 'Lakshmana'],
  ['3018', 'Chandranna'],
  ['3677', 'T Nagaraj'],
  ['4077', 'Ahmodulla Laskar'],
  ['4158', 'Chandrashekar'],
  ['4386', 'MANOHARA N'],
  ['4704', 'Ahad Uddin'],
  ['4705', 'Samad Ahmed']
];

// Work site for GPS check. Admin can change centre/radius in the app (Site settings).
const DEFAULT_SITE = { name: 'SAP Labs India (BLR04), Building 4, Whitefield', lat: 12.9789875, lng: 77.7155193, radius: 500 };
// Status codes: P Present, A Absent, H/D Half Day, EL Earned Leave, H Holiday, OFF Weekly Off, LOP Loss of Pay
const STATUS_OPTIONS = ['P', 'A', 'H/D', 'EL', 'H', 'OFF', 'LOP']; // admin-assignable
const ALL_STATUSES = STATUS_OPTIONS.concat(['Logged In', 'Logged Out']);
const MAX_GPS_ACCURACY_M = 150; // reject very weak GPS fixes

const ATTENDANCE_HEADERS = [
  'Record ID', 'Employee ID', 'Employee Name', 'Date',
  'Login Time', 'Logout Time', 'Status', 'Total Hours',
  'Login Note', 'Logout Note', 'Last Updated',
  'Login Location', 'Logout Location', 'Overtime Hours'
];
const EMPLOYEE_HEADERS = ['Employee ID', 'Employee Name', 'Active', 'Password Hash'];

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle(APP_TITLE)
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.DEFAULT);
}

/**
 * Run once from the Apps Script editor while signed in as the administrator.
 * Creates the data sheets and initializes the listed staff.
 */
function setupAttendanceApp() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Open Apps Script from a Google Sheet: Extensions > Apps Script.');
  PropertiesService.getScriptProperties().setProperty('SPREADSHEET_ID', ss.getId());

  let att = ss.getSheetByName('Attendance');
  if (!att) att = ss.insertSheet('Attendance');
  att.clear();
  att.getRange(1, 1, 1, ATTENDANCE_HEADERS.length).setValues([ATTENDANCE_HEADERS]);
  att.getRange('D:D').setNumberFormat('@');
  att.setFrozenRows(1);
  att.getRange(1, 1, 1, ATTENDANCE_HEADERS.length).setFontWeight('bold').setBackground('#4A3020').setFontColor('#FFFFFF');
  att.autoResizeColumns(1, ATTENDANCE_HEADERS.length);

  let staff = ss.getSheetByName('Employees');
  if (!staff) staff = ss.insertSheet('Employees');
  staff.clear();
  staff.getRange(1, 1, 1, EMPLOYEE_HEADERS.length).setValues([EMPLOYEE_HEADERS]);
  const rows = EMPLOYEES.map(([id, name]) => [id, name, true, hashPassword_(DEFAULT_PASSWORD)]);
  staff.getRange(2, 1, rows.length, EMPLOYEE_HEADERS.length).setValues(rows);
  staff.setFrozenRows(1);
  staff.getRange(1, 1, 1, EMPLOYEE_HEADERS.length).setFontWeight('bold').setBackground('#4A3020').setFontColor('#FFFFFF');
  staff.autoResizeColumns(1, EMPLOYEE_HEADERS.length);

  let audit = ss.getSheetByName('Audit Log');
  if (!audit) audit = ss.insertSheet('Audit Log');
  audit.clear();
  audit.appendRow(['Timestamp', 'Actor', 'Action', 'Details']);
  audit.getRange(1, 1, 1, 4).setFontWeight('bold').setBackground('#4A3020').setFontColor('#FFFFFF');
  audit.setFrozenRows(1);

  // Admin username is "admin"; only the password hash is stored.
  PropertiesService.getScriptProperties().setProperty('ADMIN_PASSWORD_HASH', hashPassword_(DEFAULT_PASSWORD));
  PropertiesService.getScriptProperties().deleteProperty('LEGACY_NOTE');
  auditLog_('system', 'SETUP', 'Sheets initialized');
  return 'Setup complete. The Employees, Attendance, and Audit Log sheets are ready.';
}

function login(username, password) {
  username = String(username || '').trim();
  password = String(password || '');
  if (!username || !password) throw new Error('Enter your user ID and password.');

  const props = PropertiesService.getScriptProperties();
  if (username.toLowerCase() === 'admin') {
    const expected = props.getProperty('ADMIN_PASSWORD_HASH');
    if (!expected || hashPassword_(password) !== expected) throw new Error('Invalid user ID or password.');
    return createSession_({ username: 'admin', role: 'admin', name: 'Administrator' });
  }

  const sh = getSheet_('Employees');
  const values = sh.getDataRange().getValues();
  const row = values.slice(1).find(r => String(r[0]).trim() === username && r[2] === true);
  if (!row || !row[3] || hashPassword_(password) !== String(row[3])) {
    throw new Error('Invalid user ID or password.');
  }
  return createSession_({ username: String(row[0]), role: 'employee', name: String(row[1]) });
}

function getMyData(token) {
  const user = requireSession_(token);
  const rows = getAttendanceRows_();
  if (user.role === 'admin') {
    return { user, employees: getEmployees_(), records: rows, today: dateKey_(new Date()), site: getSite_() };
  }
  return {
    user,
    records: rows.filter(r => String(r.employeeId) === user.username),
    today: dateKey_(new Date()),
    site: getSite_()
  };
}

function recordLogin(token, note, geo) {
  const user = requireSession_(token);
  if (user.role !== 'employee') throw new Error('Use an employee account to record attendance.');
  const loc = verifyLocation_(geo);
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const sh = getSheet_('Attendance');
    const today = dateKey_(new Date());
    const values = sh.getDataRange().getValues();
    for (let i = 1; i < values.length; i++) {
      if (String(values[i][1]) === user.username && dayOf_(values[i][3]) === today && values[i][4] && !values[i][5]) {
        throw new Error('You are already logged in. Please log out first.');
      }
    }
    const now = new Date();
    const id = Utilities.getUuid();
    sh.appendRow([id, user.username, user.name, today, now, '', 'Logged In', '', cleanText_(note, 250), '', now, loc, '', 0]);
    auditLog_(user.username, 'LOGIN', today);
    return { message: 'Login recorded successfully.', data: getMyData(token) };
  } finally {
    lock.releaseLock();
  }
}

function recordLogout(token, note, geo) {
  const user = requireSession_(token);
  if (user.role !== 'employee') throw new Error('Use an employee account to record attendance.');
  const loc = verifyLocation_(geo);
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const sh = getSheet_('Attendance');
    const values = sh.getDataRange().getValues();
    const today = dateKey_(new Date());
    for (let i = values.length - 1; i >= 1; i--) {
      if (String(values[i][1]) === user.username && dayOf_(values[i][3]) === today && values[i][4] && !values[i][5]) {
        const now = new Date();
        const loginTime = values[i][4] instanceof Date ? values[i][4] : new Date(values[i][4]);
        const hours = Math.max(0, (now.getTime() - loginTime.getTime()) / 3600000);
        sh.getRange(i + 1, 6, 1, 6).setValues([[now, 'Logged Out', hours, values[i][8] || '', cleanText_(note, 250), now]]);
        sh.getRange(i + 1, 13).setValue(loc);
        auditLog_(user.username, 'LOGOUT', today);
        return { message: 'Logout recorded successfully.', data: getMyData(token) };
      }
    }
    throw new Error('No open login found for today.');
  } finally {
    lock.releaseLock();
  }
}

function adminSaveEmployee(token, employee) {
  const admin = requireAdmin_(token);
  const id = cleanText_(employee && employee.id, 30);
  const name = cleanText_(employee && employee.name, 100);
  const active = Boolean(employee && employee.active);
  if (!/^[A-Za-z0-9_-]{2,30}$/.test(id) || !name) throw new Error('Enter a valid employee ID and name.');
  const sh = getSheet_('Employees');
  const values = sh.getDataRange().getValues();
  let foundRow = -1;
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][0]) === id) { foundRow = i + 1; break; }
  }
  if (foundRow > 0) {
    sh.getRange(foundRow, 2, 1, 2).setValues([[name, active]]);
  } else {
    sh.appendRow([id, name, active, hashPassword_(DEFAULT_PASSWORD)]);
  }
  auditLog_(admin.username, 'SAVE_EMPLOYEE', id + ' / ' + name);
  return getMyData(token);
}

function adminResetEmployeePassword(token, employeeId, newPassword) {
  const admin = requireAdmin_(token);
  employeeId = String(employeeId || '').trim();
  newPassword = String(newPassword || '');
  if (newPassword.length < 8) throw new Error('Password must be at least 8 characters.');
  const sh = getSheet_('Employees');
  const values = sh.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][0]) === employeeId) {
      sh.getRange(i + 1, 4).setValue(hashPassword_(newPassword));
      auditLog_(admin.username, 'RESET_PASSWORD', employeeId);
      return { message: 'Password updated.' };
    }
  }
  throw new Error('Employee ID not found.');
}

function adminUpdateRecord(token, recordId, patch) {
  const admin = requireAdmin_(token);
  const sh = getSheet_('Attendance');
  const values = sh.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][0]) === String(recordId)) {
      const row = i + 1;
      if (patch.date !== undefined) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(patch.date))) throw new Error('Date must be YYYY-MM-DD.');
        sh.getRange(row, 4).setValue(String(patch.date));
      }
      if (patch.login !== undefined) sh.getRange(row, 5).setValue(parseLocal_(patch.login));
      if (patch.logout !== undefined) sh.getRange(row, 6).setValue(parseLocal_(patch.logout));
      if (patch.status !== undefined) {
        const st = cleanText_(patch.status, 40);
        if (ALL_STATUSES.indexOf(st) < 0) throw new Error('Status must be one of: ' + ALL_STATUSES.join(', ') + '.');
        sh.getRange(row, 7).setValue(st);
      }
      if (patch.overtime !== undefined) {
        const ot = Number(patch.overtime === '' ? 0 : patch.overtime);
        if (!isFinite(ot) || ot < 0 || ot > 24) throw new Error('Overtime must be between 0 and 24 hours.');
        sh.getRange(row, 14).setValue(ot);
      }
      const login = sh.getRange(row, 5).getValue();
      const logout = sh.getRange(row, 6).getValue();
      if (login && logout) {
        if (new Date(logout) < new Date(login)) throw new Error('Logout time cannot be before login time.');
        sh.getRange(row, 8).setValue((new Date(logout) - new Date(login)) / 3600000);
        if (patch.status === undefined && sh.getRange(row, 7).getValue() === 'Logged In') sh.getRange(row, 7).setValue('Logged Out');
      } else {
        sh.getRange(row, 8).setValue('');
      }
      sh.getRange(row, 11).setValue(new Date());
      auditLog_(admin.username, 'EDIT_ATTENDANCE', String(recordId));
      return getMyData(token);
    }
  }
  throw new Error('Attendance record not found.');
}

/**
 * Admin marks a status (Present, Half Day, LOP, EL, Holiday, Week Off, Absent) and optional
 * overtime for one employee or ALL active employees over a date range (max 62 days).
 */
function adminMarkDays(token, req) {
  const admin = requireAdmin_(token);
  req = req || {};
  const status = String(req.status || '');
  if (STATUS_OPTIONS.indexOf(status) < 0) throw new Error('Choose a valid status.');
  const hasOt = !(req.overtime === '' || req.overtime == null);
  const ot = hasOt ? Number(req.overtime) : 0;
  if (hasOt && (!isFinite(ot) || ot < 0 || ot > 24)) throw new Error('Overtime must be between 0 and 24 hours.');
  const from = String(req.from || ''), to = String(req.to || req.from || '');
  const re = /^\d{4}-\d{2}-\d{2}$/;
  if (!re.test(from) || !re.test(to) || to < from) throw new Error('Enter a valid date range.');
  const days = [];
  for (let d = new Date(from + 'T00:00:00Z'), end = new Date(to + 'T00:00:00Z'); d <= end; d = new Date(d.getTime() + 86400000)) {
    days.push(d.toISOString().slice(0, 10));
  }
  if (days.length > 62) throw new Error('Choose at most 62 days at a time.');
  const all = getEmployees_();
  const targets = String(req.employeeId) === 'ALL' ? all.filter(e => e.active) : all.filter(e => e.id === String(req.employeeId));
  if (!targets.length) throw new Error('Employee not found.');

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const sh = getSheet_('Attendance');
    const values = sh.getDataRange().getValues();
    const index = {};
    for (let i = 1; i < values.length; i++) {
      const key = String(values[i][1]) + '|' + dayOf_(values[i][3]);
      if (!(key in index)) index[key] = i + 1;
    }
    const now = new Date(), fresh = [];
    targets.forEach(e => days.forEach(day => {
      const row = index[e.id + '|' + day];
      if (row) {
        sh.getRange(row, 7).setValue(status);
        if (hasOt) sh.getRange(row, 14).setValue(ot);
        sh.getRange(row, 11).setValue(now);
      } else {
        fresh.push([Utilities.getUuid(), e.id, e.name, day, '', '', status, '', 'Marked by admin', '', now, '', '', ot]);
      }
    }));
    if (fresh.length) sh.getRange(sh.getLastRow() + 1, 1, fresh.length, ATTENDANCE_HEADERS.length).setValues(fresh);
    auditLog_(admin.username, 'MARK_DAYS', status + ' ' + from + '..' + to + ' for ' + (String(req.employeeId) === 'ALL' ? 'ALL' : req.employeeId) + (hasOt ? ' OT=' + ot : ''));
    return getMyData(token);
  } finally {
    lock.releaseLock();
  }
}

/**
 * Daily sheet save: entries = [{id, code, overtime}] for one date. Blank code / blank overtime = leave unchanged.
 */
function adminSaveDaily(token, date, entries) {
  const admin = requireAdmin_(token);
  date = String(date || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error('Choose a valid date.');
  if (!Array.isArray(entries) || !entries.length) throw new Error('Nothing to save.');
  if (entries.length > 200) throw new Error('Too many rows at once.');
  const emps = {};
  getEmployees_().forEach(e => { emps[e.id] = e; });
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const sh = getSheet_('Attendance');
    const values = sh.getDataRange().getValues();
    const index = {};
    for (let i = 1; i < values.length; i++) {
      const key = String(values[i][1]) + '|' + dayOf_(values[i][3]);
      if (!(key in index)) index[key] = i + 1;
    }
    const now = new Date(), fresh = [], log = [];
    entries.forEach(en => {
      const id = String(en && en.id || '');
      const emp = emps[id];
      if (!emp) throw new Error('Unknown employee ' + id + '.');
      const code = String(en.code || '');
      if (code && STATUS_OPTIONS.indexOf(code) < 0) throw new Error('Invalid status code: ' + code);
      const hasOt = !(en.overtime === '' || en.overtime == null);
      const ot = hasOt ? Number(en.overtime) : 0;
      if (hasOt && (!isFinite(ot) || ot < 0 || ot > 24)) throw new Error('Overtime must be between 0 and 24 hours (' + id + ').');
      if (!code && !hasOt) return;
      const row = index[id + '|' + date];
      if (row) {
        if (code) sh.getRange(row, 7).setValue(code);
        if (hasOt) sh.getRange(row, 14).setValue(ot);
        sh.getRange(row, 11).setValue(now);
      } else {
        fresh.push([Utilities.getUuid(), id, emp.name, date, '', '', code, '', 'Marked by admin', '', now, '', '', ot]);
      }
      log.push(id + ':' + (code || '-') + (hasOt ? '/OT' + ot : ''));
    });
    if (fresh.length) sh.getRange(sh.getLastRow() + 1, 1, fresh.length, ATTENDANCE_HEADERS.length).setValues(fresh);
    auditLog_(admin.username, 'DAILY_SHEET', date + ' ' + log.join(', '));
    return getMyData(token);
  } finally {
    lock.releaseLock();
  }
}

function adminDeleteRecord(token, recordId) {
  const admin = requireAdmin_(token);
  const sh = getSheet_('Attendance');
  const values = sh.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][0]) === String(recordId)) {
      sh.deleteRow(i + 1);
      auditLog_(admin.username, 'DELETE_ATTENDANCE', String(recordId));
      return getMyData(token);
    }
  }
  throw new Error('Attendance record not found.');
}

function adminSaveSite(token, site) {
  const admin = requireAdmin_(token);
  const name = cleanText_(site && site.name, 120);
  const lat = Number(site && site.lat), lng = Number(site && site.lng), radius = Number(site && site.radius);
  if (!name || !isFinite(lat) || !isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) throw new Error('Enter a valid site name, latitude and longitude.');
  if (!isFinite(radius) || radius < 50 || radius > 5000) throw new Error('Radius must be between 50 and 5000 metres.');
  const p = PropertiesService.getScriptProperties();
  p.setProperty('SITE_NAME', name); p.setProperty('SITE_LAT', String(lat));
  p.setProperty('SITE_LNG', String(lng)); p.setProperty('SITE_RADIUS', String(radius));
  auditLog_(admin.username, 'SAVE_SITE', name + ' ' + lat + ',' + lng + ' r=' + radius);
  return getMyData(token);
}

function getSite_() {
  const p = PropertiesService.getScriptProperties();
  const num = (k, d) => { const v = Number(p.getProperty(k)); return p.getProperty(k) && isFinite(v) ? v : d; };
  return { name: p.getProperty('SITE_NAME') || DEFAULT_SITE.name, lat: num('SITE_LAT', DEFAULT_SITE.lat),
           lng: num('SITE_LNG', DEFAULT_SITE.lng), radius: num('SITE_RADIUS', DEFAULT_SITE.radius) };
}
function distanceM_(lat1, lng1, lat2, lng2) {
  const R = 6371000, rad = x => x * Math.PI / 180;
  const dLat = rad(lat2 - lat1), dLng = rad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}
// Throws unless the phone's GPS fix is inside the work-site radius. Returns text stored in the sheet.
function verifyLocation_(geo) {
  const lat = Number(geo && geo.lat), lng = Number(geo && geo.lng), acc = Number(geo && geo.acc);
  if (!geo || !isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
    throw new Error('Location is required. Allow location access in your browser and try again.');
  }
  if (isFinite(acc) && acc > MAX_GPS_ACCURACY_M) {
    throw new Error('GPS signal is weak (about ' + Math.round(acc) + ' m). Move near a window or outdoors and try again.');
  }
  const site = getSite_();
  const dist = distanceM_(lat, lng, site.lat, site.lng);
  if (dist > site.radius) {
    throw new Error('You are about ' + Math.round(dist) + ' m from ' + site.name + '. Attendance is allowed only within ' + site.radius + ' m.');
  }
  return lat.toFixed(6) + ', ' + lng.toFixed(6) + ' (' + Math.round(dist) + ' m from site)';
}

function logoutSession(token) {
  if (token) CacheService.getScriptCache().remove('sess_' + token);
  return true;
}

function createSession_(user) {
  const token = Utilities.getUuid() + Utilities.getUuid();
  CacheService.getScriptCache().put('sess_' + token, JSON.stringify(user), 21600);
  return { token, user };
}

function requireSession_(token) {
  if (!token) throw new Error('Your session has expired. Please log in again.');
  const raw = CacheService.getScriptCache().get('sess_' + token);
  if (!raw) throw new Error('Your session has expired. Please log in again.');
  return JSON.parse(raw);
}
function requireAdmin_(token) {
  const user = requireSession_(token);
  if (user.role !== 'admin') throw new Error('Administrator access required.');
  return user;
}
function getSheet_(name) {
  const id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  if (!id) throw new Error('Admin setup is incomplete. Run setupAttendanceApp() first.');
  const ss = SpreadsheetApp.openById(id);
  const sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Missing sheet: ' + name + '. Run setupAttendanceApp() again.');
  return sh;
}
function getEmployees_() {
  return getSheet_('Employees').getDataRange().getValues().slice(1).filter(r => r[0]).map(r => ({
    id: String(r[0]), name: String(r[1]), active: r[2] === true
  }));
}
function getAttendanceRows_() {
  const vals = getSheet_('Attendance').getDataRange().getValues();
  return vals.slice(1).filter(r => r[0]).map(r => ({
    recordId: String(r[0]), employeeId: String(r[1]), employeeName: String(r[2]),
    date: r[3] instanceof Date ? dateKey_(r[3]) : String(r[3] || ''),
    login: formatDateTime_(r[4]), logout: formatDateTime_(r[5]),
    status: String(r[6] || ''), hours: r[7] === '' ? '' : Number(r[7]),
    loginNote: String(r[8] || ''), logoutNote: String(r[9] || ''),
    updated: formatDateTime_(r[10]),
    loginIso: isoLocal_(r[4]), logoutIso: isoLocal_(r[5]),
    loginLoc: String(r[11] || ''), logoutLoc: String(r[12] || ''),
    overtime: r[13] === '' || r[13] == null ? 0 : Number(r[13])
  }));
}
function hashPassword_(password) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(password), Utilities.Charset.UTF_8);
  return bytes.map(b => ('0' + ((b + 256) % 256).toString(16)).slice(-2)).join('');
}
// 'yyyy-MM-ddTHH:mm' (as typed by an admin, India time) -> Date; '' -> ''
function parseLocal_(s) {
  s = String(s || '').trim();
  if (!s) return '';
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(s)) throw new Error('Enter a valid date and time.');
  return Utilities.parseDate(s, Session.getScriptTimeZone() || 'Asia/Kolkata', "yyyy-MM-dd'T'HH:mm");
}
function isoLocal_(v) {
  if (!v) return '';
  const d = v instanceof Date ? v : new Date(v);
  return isNaN(d.getTime()) ? '' : Utilities.formatDate(d, Session.getScriptTimeZone() || 'Asia/Kolkata', "yyyy-MM-dd'T'HH:mm");
}
function dayOf_(v) {
  return v instanceof Date ? dateKey_(v) : String(v || '');
}
function dateKey_(d) {
  return Utilities.formatDate(d, Session.getScriptTimeZone() || 'Asia/Kolkata', 'yyyy-MM-dd');
}
function formatDateTime_(value) {
  if (!value) return '';
  const d = value instanceof Date ? value : new Date(value);
  if (isNaN(d.getTime())) return String(value);
  return Utilities.formatDate(d, Session.getScriptTimeZone() || 'Asia/Kolkata', 'dd-MMM-yyyy hh:mm a');
}
function cleanText_(value, max) {
  return String(value || '').replace(/[<>]/g, '').trim().slice(0, max);
}
function auditLog_(actor, action, details) {
  try { getSheet_('Audit Log').appendRow([new Date(), actor, action, details]); } catch (e) {}
}
